from .  import myModule
